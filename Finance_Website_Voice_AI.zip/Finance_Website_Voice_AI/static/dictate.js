function dictateF() {
	var msg = new SpeechSynthesisUtterance();
	msg.text = "What Is Equity? Equity, typically referred to as shareholders equity (or owners equity for privately held companies), represents the amount of money that would be returned to a companys shareholders if all of the assets were liquidated and all of the companys debt was paid off in the case of liquidation. In the case of acquisition, it is the value of company sales minus any liabilities owed by the company not transferred with the sale.";
	window.speechSynthesis.speak(msg);
}