function searchT(){
    var x = document.getElementById("search-box").value;
    if(x.includes("equity")){
        window.location.href = "/equity";
    }
    else if(x.includes("basic")){
        window.location.href = "/bof";
    }
    else if(x.includes("government")){
        window.location.href = "/gf";
    }
    else if(x.includes("personal")){
        window.location.href = "/pf";
    }
    else if(x.includes("corporate")){
        window.location.href = "/cf";
    }
    else{
        alert("Sorry! Data not available");
    }
}