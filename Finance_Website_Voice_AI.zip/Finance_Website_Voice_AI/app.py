from flask import Flask, render_template, request, redirect
import speech_recognition as sr

app = Flask(__name__)


def voiceS(html_file):
    transcript = ""
    file = html_file
    if request.method == "POST":
        r = sr.Recognizer()

        try:
            with sr.Microphone() as source2:
                r.adjust_for_amchbient_noise(source2, duration=0.2)
                audio2 = r.listen(source2, 10, 3)
                MyText = r.recognize_google(audio2)
                transcript = MyText.lower()

                print("Did you say " + transcript)

        except sr.RequestError as e:
            error = "request"
            print("Could not request results; {0}".format(e))
            return render_template('voice_error.html', transcript=error)

        except sr.UnknownValueError:
            print("unknown error occured")
            error = "unknown"
            return render_template('voice_error.html', transcript=error)
    return render_template(file, transcript=transcript)


@app.route("/", methods=["GET", "POST"])
def index():
    return voiceS('indexUI.html')


@app.route("/bof", methods=["GET", "POST"])
def home():
    return voiceS('Basics of Finance.html')


@app.route("/equity", methods=["GET", "POST"])
def page1():
    return voiceS('equity.html')


@app.route("/cf", methods=["GET", "POST"])
def page2():
    return voiceS('Corporate Finance.html')


@app.route("/gf", methods=["GET", "POST"])
def page3():
    return voiceS('Goverment Finance.html')


@app.route("/pf", methods=["GET", "POST"])
def page4():
    return voiceS('Personal Finance.html')


@app.route("/con", methods=["GET", "POST"])
def page5():
    return voiceS('contact.html')


if __name__ == "__main__":
    app.run(debug=True, threaded=True)
