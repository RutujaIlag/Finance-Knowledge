<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Speech Recognition in Python</title>
    <link rel= "stylesheet" type= "text/css" href= "{{ url_for('static',filename='style.css') }}">
    <script type="text/javascript" src="{{ url_for('static', filename = 'voiceload.js') }}"></script>
    <script type="text/javascript" src="{{ url_for('static', filename = 'search.js') }}"></script>
    <script type="text/javascript" src="{{ url_for('static', filename = 'index1.js') }}"></script>
    <script src="https://kit.fontawesome.com/85ff87178a.js" crossorigin="anonymous"></script>
</head>

<body>

<div id = "speechContainer" class="form-container">
    <form method="post" enctype="multipart/form-data" class="form">

        <button type="submit"><i class="fas fa-microphone"></i></button>
        <input id="dis" type="text" name="res"/>
    </form>

    {% if transcript != "" %}
        {% if transcript == "equity" %}
            <div id="speechTranscriptContainer">
                <h1>Transcript</h1>
                <h1 id = "para">{{transcript}}</h1>
                <h1>Equity What Is Equity? Equity, typically referred to as shareholders equity (or owners equity for privately held companies), represents the amount of money that would be returned to a companys shareholders if all of the assets were liquidated and all of the companys debt was paid off in the case of liquidation. In the case of acquisition, it is the value of company sales minus any liabilities owed by the company not transferred with the sale.</h1>
            </div>
        {% else %}
            <h1>Data Not Available</h1>
        {% endif %}
    {% endif %}

</div>
</body>
</html>